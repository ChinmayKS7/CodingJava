package com.simpli;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpSession;

@WebServlet("/AdminLogoutServlet")
public class AdminLogoutServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve the current session or create a new one if it doesn't exist
        HttpSession session = request.getSession(false);

        if (session != null) {
            // Set a logout message in the session
            String logoutMessage = "You have been successfully logged out.";
            session.setAttribute("logoutMessage", logoutMessage);

            // Invalidate the session to log out the user
            session.invalidate();
        }

        // Redirect the user to the login page with a logout message
        response.sendRedirect("admin-login.jsp?logout=true");
    }
}