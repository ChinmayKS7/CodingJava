package com.simpli;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.annotation.WebServlet;

@WebServlet("/FavoriteCrossingsServlet")
public class FavoriteCrossingsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static final String DB_URL = "jdbc:mysql://localhost:3306/railwaycrossing";
    private static final String DB_USERNAME = "root";
    private static final String DB_PASSWORD = "tiger";

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Favorite Crossings</title>");
            out.println("</head>");
            out.println("<body>");

            // Retrieve and display favorite crossings
            List<Crossing> favoriteCrossings = getFavoriteCrossings();
            out.println("<h1>Favorite Crossings</h1>");
            if (favoriteCrossings.isEmpty()) {
                out.println("<p>No favorite crossings found.</p>");
            } else {
                for (Crossing crossing : favoriteCrossings) {
                    out.println("<h3>" + crossing.getCrossingName() + "</h3>");
                    out.println("<p>Crossing Status: " + crossing.getCrossingStatus() + "</p>");
                    out.println("<p>Person in Charge: " + crossing.getPersonInCharge() + "</p>");
                    out.println("<p>Train Schedule: " + crossing.getTrainSchedule() + "</p>");
                    out.println("<p>Landmark: " + crossing.getLandmark() + "</p>");
                    out.println("<p>Address: " + crossing.getAddress() + "</p>");
                    out.println("<hr>");
                }
            }

            out.println("</body>");
            out.println("</html>");
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().println("Database error: " + e.getMessage());
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String crossingIdStr = request.getParameter("crossingId");
        String favoriteAction = request.getParameter("favoriteAction");

        if (crossingIdStr != null && favoriteAction != null) {
            int crossingId = Integer.parseInt(crossingIdStr);
            if (favoriteAction.equals("Add to Favorites")) {
                try {
					addFavoriteCrossing(crossingId);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
                request.setAttribute("favoriteAction", "added");
            } else if (favoriteAction.equals("Remove from Favorites")) {
                try {
					removeFavoriteCrossing(crossingId);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
                request.setAttribute("favoriteAction", "removed");
            }
        }

        // Redirect to doGet method to display the favorite crossings
        response.sendRedirect("FavoriteCrossingsServlet");
    }

    private List<Crossing> getFavoriteCrossings() throws SQLException {
        List<Crossing> favoriteCrossings = new ArrayList<>();
        String sql = "SELECT * FROM crossing WHERE id IN (SELECT crossing_id FROM favorite_crossings)";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
             PreparedStatement statement = conn.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
            	Crossing crossing = new Crossing();
                crossing.setId(resultSet.getInt("id"));
                crossing.setCrossingName(resultSet.getString("crossing_name"));
                crossing.setCrossingStatus(resultSet.getString("crossing_status"));
                crossing.setPersonInCharge(resultSet.getString("person_in_charge"));
                crossing.setTrainSchedule(resultSet.getString("train_schedule"));
                crossing.setLandmark(resultSet.getString("landmark"));
                crossing.setAddress(resultSet.getString("address"));
                favoriteCrossings.add(crossing);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
        return favoriteCrossings;
    }

    private void addFavoriteCrossing(int crossingId) throws SQLException {
        String sql = "INSERT INTO favorite_crossings (crossing_id) VALUES (?)";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
             PreparedStatement statement = conn.prepareStatement(sql)) {
            statement.setInt(1, crossingId);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
    }

    private void removeFavoriteCrossing(int crossingId) throws SQLException {
        String sql = "DELETE FROM favorite_crossings WHERE crossing_id = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
             PreparedStatement statement = conn.prepareStatement(sql)) {
            statement.setInt(1, crossingId);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
    }
}
            