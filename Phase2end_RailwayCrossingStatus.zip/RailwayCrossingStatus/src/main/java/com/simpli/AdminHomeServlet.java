package com.simpli;

import java.io.*;
import java.sql.*;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/AdminHomeServlet")
public class AdminHomeServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Set response content type
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Generate the HTML page
        out.println("<html>");
        out.println("<head><title>Admin Home - Railway Crossing Database</title>");
        out.println("<style>");
        out.println("table {border-collapse: collapse;}");
        out.println("th, td {padding: 10px;}");
        out.println(".nav-link {text-decoration: none; margin-right: 10px;}");
        out.println("</style>");
        out.println("</head>");
        out.println("<body>");
        out.println("<header><h1>Welcome to Admin Home</h1></header>");
        out.println("<nav>");
        out.println("<ul>");
        out.println("<li><a href='AdminHomeServlet' class='nav-link'>Home</a></li>");
        out.println("<li><a href='addcrossing.jsp' class='nav-link'>Add Railway Crossing</a></li>");
        out.println("<li><a href='AdminLogoutServlet' class='nav-link'>Logout</a></li>");
        out.println("</ul>");
        out.println("</nav>");
        out.println("<main>");
        out.println("<h2>Railway Crossing Table</h2>");

        // Add search input field
        out.println("<form method='GET' action='AdminHomeServlet'>");
        out.println("<input type='text' name='search' placeholder='Search crossing...'>");
        out.println("<input type='submit' value='Search'>");
        out.println("</form>");

        out.println("<table>");
        out.println("<thead>");
        out.println("<tr>");
        out.println("<th>Sr No</th>");
        out.println("<th>Name</th>");
        out.println("<th>Address</th>");
        out.println("<th>Landmark</th>");
        out.println("<th>Train Schedule</th>");
        out.println("<th>Person-in-charge</th>");
        out.println("<th>Status</th>");
        out.println("<th>Action</th>");
        out.println("</tr>");
        out.println("</thead>");
        out.println("<tbody>");

        // Database credentials and connection
        String jdbcURL = "jdbc:mysql://localhost:3306/railwaycrossing";
        String dbUser = "root";
        String dbPassword = "tiger";

        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            // Establish a connection to the database
            connection = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);

            // Create a statement for executing SQL queries
            statement = connection.createStatement();

            // Retrieve the search query
            String searchQuery = request.getParameter("search");

            // Execute the SQL query to retrieve crossing data
            String sql;
            if (searchQuery != null && !searchQuery.isEmpty()) {
                sql = "SELECT * FROM crossing WHERE crossing_name LIKE '%" + searchQuery + "%'";
            } else {
                sql = "SELECT * FROM crossing";
            }
            resultSet = statement.executeQuery(sql);

         // Iterate over the result set and populate table rows
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String crossingName = resultSet.getString("crossing_name");
                String address = resultSet.getString("address");
                String landmark = resultSet.getString("landmark");
                String trainSchedule = resultSet.getString("train_schedule");
                String personInCharge = resultSet.getString("person_in_charge");
                String crossingStatus = resultSet.getString("crossing_status");

                out.println("<tr>");
                out.println("<td>" + id + "</td>");
                out.println("<td>" + crossingName + "</td>");
                out.println("<td>" + address + "</td>");
                out.println("<td>" + landmark + "</td>");
                out.println("<td>" + trainSchedule + "</td>");
                out.println("<td>" + personInCharge + "</td>");
                out.println("<td>" + crossingStatus + "</td>");
                out.println("<td><a href='update_crossing_form.jsp?id="+id+"'>Update</a> | "
                        + "<a href='delete_crossing?id=" + id + "'>Delete</a></td>");
                out.println("</tr>");
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close the database resources
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

        out.println("</tbody>");
        out.println("</table>");
        out.println("</main>");
        out.println("</body>");
        out.println("</html>");
    }}