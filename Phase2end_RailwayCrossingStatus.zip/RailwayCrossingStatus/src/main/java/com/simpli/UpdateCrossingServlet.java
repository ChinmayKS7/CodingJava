package com.simpli;

import java.io.*;
import java.sql.*;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/UpdateCrossingServlet")
public class UpdateCrossingServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve the form data
        int crossingId = Integer.parseInt(request.getParameter("id"));
        String crossingName = request.getParameter("crossingName");
        String address = request.getParameter("address");
        String landmark = request.getParameter("landmark");
        String trainSchedule = request.getParameter("trainSchedule");
        String personInCharge = request.getParameter("personInCharge");
        String crossingStatus = request.getParameter("crossingStatus");

        // Database credentials and connection
        String jdbcURL = "jdbc:mysql://localhost:3306/railwaycrossing";
        String dbUser = "root";
        String dbPassword = "tiger";

        Connection connection = null;
        PreparedStatement statement = null;

        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            // Establish a connection to the database
            connection = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);

            // Create a prepared statement for updating the crossing data
            String sql = "UPDATE crossing SET crossing_name=?, address=?, landmark=?, train_schedule=?, person_in_charge=?, crossing_status=? WHERE id=?";
            statement = connection.prepareStatement(sql);
         // Set the parameters for the prepared statement
            statement.setString(1, crossingName);
            statement.setString(2, address);
            statement.setString(3, landmark);
            statement.setString(4, trainSchedule);
            statement.setString(5, personInCharge);
            statement.setString(6, crossingStatus);
            statement.setInt(7, crossingId);

            // Execute the update query
            int rowsAffected = statement.executeUpdate();

            // Redirect to the AdminHomeServlet after successful update
            if (rowsAffected > 0) {
                response.sendRedirect("AdminHomeServlet");
            } else {
                // Handle update failure
                response.setContentType("text/html");
                PrintWriter out = response.getWriter();
                out.println("<html><body><h3>Error: Failed to update crossing</h3></body></html>");
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close the database resources
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}