package com.simpli;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class UserDAO {
    public void addUser(User user) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = null;
        
        try {
            transaction = session.beginTransaction();
            session.save(user);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
        }
    }
    
    public User getUserByEmail(String email) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        User user = null;
        
        try {
            user = session.createQuery("FROM User WHERE email = :email", User.class)
                .setParameter("email", email)
                .uniqueResult();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        
        return user;
    }
}