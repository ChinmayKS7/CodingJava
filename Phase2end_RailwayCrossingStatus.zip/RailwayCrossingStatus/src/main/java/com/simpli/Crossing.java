package com.simpli;
public class Crossing {
    private int id;
    private String crossingName;
    private String crossingStatus;
    private String personInCharge;
    private String trainSchedule;
    private String landmark;
    private String address;

    public Crossing(int id, String crossingName, String crossingStatus, String personInCharge, String trainSchedule,
            String landmark, String address) {
        this.id = id;
        this.crossingName = crossingName;
        this.crossingStatus = crossingStatus;
        this.personInCharge = personInCharge;
        this.trainSchedule = trainSchedule;
        this.landmark = landmark;
        this.address = address;
    }

    // Getters and Setters

    public Crossing() {
		
	}

	public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCrossingName() {
        return crossingName;
    }

    public void setCrossingName(String crossingName) {
        this.crossingName = crossingName;
    }

    public String getCrossingStatus() {
        return crossingStatus;
    }

    public void setCrossingStatus(String crossingStatus) {
        this.crossingStatus = crossingStatus;
    }

    public String getPersonInCharge() {
        return personInCharge;
    }

    public void setPersonInCharge(String personInCharge) {
        this.personInCharge = personInCharge;
    }

    public String getTrainSchedule() {
        return trainSchedule;
    }

    public void setTrainSchedule(String trainSchedule) {
        this.trainSchedule = trainSchedule;
    }

    public String getLandmark() {
        return landmark;
    }

    public void setLandmark(String landmark) {
        this.landmark = landmark;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}