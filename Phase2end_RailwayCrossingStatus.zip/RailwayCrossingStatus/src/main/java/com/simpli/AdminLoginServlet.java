package com.simpli;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/AdminLoginServlet")
public class AdminLoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Hard-coded admin username and password for demonstration purposes
    private static final String ADMIN_USERNAME = "admin";
    private static final String ADMIN_PASSWORD = "admin123";

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        PrintWriter out = response.getWriter();
        HttpSession session = request.getSession();

        // Check if the provided username and password match the admin credentials
        if (username.equals(ADMIN_USERNAME) && password.equals(ADMIN_PASSWORD)) {
            // Authentication successful, store admin flag in session
            session.setAttribute("isAdmin", true);
            response.sendRedirect("AdminHomeServlet");
        } else {
            // Authentication failed, display error message and redirect to admin-login.jsp
            out.println("<script type='text/javascript'>");
            out.println("alert('Invalid username or password');");
            out.println("location='admin-login.jsp';");
            out.println("</script>");
        }
    }
}