package com.simpli;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/AddCrossingServlet")
public class AddCrossingServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve form data
        String crossingName = request.getParameter("crossingName");
        String address = request.getParameter("address");
        String landmark = request.getParameter("landmark");
        String trainSchedule = request.getParameter("trainSchedule");
        String personInCharge = request.getParameter("personInCharge");
        String crossingStatus = request.getParameter("crossingStatus");

        // Database credentials and connection
        String jdbcURL = "jdbc:mysql://localhost:3306/railwaycrossing";
        String dbUser = "root";
        String dbPassword = "tiger";

        Connection connection = null;
        PreparedStatement statement = null;

        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            // Establish a connection to the database
            connection = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);

            // Create a prepared statement for inserting the crossing data
            String sql = "INSERT INTO crossing (crossing_name, address, landmark, train_schedule, person_in_charge, crossing_status) VALUES (?, ?, ?, ?, ?, ?)";
            statement = connection.prepareStatement(sql);
            statement.setString(1, crossingName);
            statement.setString(2, address);
            statement.setString(3, landmark);
            statement.setString(4, trainSchedule);
            statement.setString(5, personInCharge);
            statement.setString(6, crossingStatus);

            // Execute the statement to insert the data
            int rowsInserted = statement.executeUpdate();

            // Check if the insertion was successful
            if (rowsInserted > 0) {
                response.sendRedirect("AdminHomeServlet");
            } else {
                response.getWriter().println("Failed to add the crossing.");
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close the database resources
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}