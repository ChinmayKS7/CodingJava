package com.simpli;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.annotation.WebServlet;

@WebServlet("/DashboardServlet")
public class DashboardServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static final String DB_URL = "jdbc:mysql://localhost:3306/railwaycrossing";
    private static final String DB_USERNAME = "root";
    private static final String DB_PASSWORD = "tiger";

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        try (PrintWriter out = response.getWriter()) {
            String searchName = request.getParameter("searchName");
            List<Crossing> crossings = searchCrossings(searchName);
            
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Railway Crossings</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Railway Crossings</h1>");
            out.println("<h3>User Home Page</h3>");

            // Display options
            out.println("<p><a href=\"DashboardServlet\">All Crossings</a></p>");
            out.println("<p><a href=\"FavoriteCrossingsServlet\">Favorite Crossings</a></p>");
            out.println("<p><a href=\"LogoutServlet\">Logout</a></p>");

            // Search form
            out.println("<h3>Search Railway Crossing</h3>");
            out.println("<form method=\"GET\" action=\"DashboardServlet\">");
            out.println("<input type=\"text\" name=\"searchName\" placeholder=\"Enter name\">");
            out.println("<input type=\"submit\" value=\"Search\">");
            out.println("</form>");

            // Display crossing details
            for (Crossing crossing : crossings) {
                out.println("<h3>" + crossing.getCrossingName() + "</h3>");
                out.println("<p>Crossing Status: " + crossing.getCrossingStatus() + "</p>");
                out.println("<p>Person in Charge: " + crossing.getPersonInCharge() + "</p>");
                out.println("<p>Train Schedule: " + crossing.getTrainSchedule() + "</p>");
                out.println("<p>Landmark: " + crossing.getLandmark() + "</p>");
                out.println("<p>Address: " + crossing.getAddress() + "</p>");

                // Check if the crossing is already a favorite
                boolean isFavorite = checkIfFavoriteCrossing(crossing.getId());

                out.println("<form method=\"POST\" action=\"FavoriteCrossingsServlet\">");
                out.println("<input type=\"hidden\" name=\"crossingId\" value=\"" + crossing.getId() + "\">");

                if (isFavorite) {
                    out.println("<input type=\"submit\" name=\"favoriteAction\" value=\"Remove from Favorites\">");
                } else {
                    out.println("<input type=\"submit\" name=\"favoriteAction\" value=\"Add to Favorites\">");
                }

                out.println("</form>");
                out.println("<hr>");
            }
            
            // Display success messages if any
            String favoriteAction = (String) request.getAttribute("favoriteAction");
            if (favoriteAction != null) {
                if (favoriteAction.equals("added")) {
                    out.println("<p>Added to favorites successfully!</p>");
                } else if (favoriteAction.equals("removed")) {
                    out.println("<p>Removed from favorites successfully!</p>");
                }
            }

            out.println("</body>");
            out.println("</html>");
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().println("Database error: " + e.getMessage());
        }
    }

    private List<Crossing> searchCrossings(String searchName) throws SQLException {
        List<Crossing> crossings = new ArrayList<>();
        String sql = "SELECT * FROM crossing";
        if (searchName != null && !searchName.isEmpty()) {
            sql += " WHERE crossing_name LIKE '%" + searchName + "%'";
        }
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
             PreparedStatement statement = conn.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                Crossing crossing = new Crossing();
                crossing.setId(resultSet.getInt("id"));
                crossing.setCrossingName(resultSet.getString("crossing_name"));
                crossing.setCrossingStatus(resultSet.getString("crossing_status"));
                crossing.setPersonInCharge(resultSet.getString("person_in_charge"));
                crossing.setTrainSchedule(resultSet.getString("train_schedule"));
                crossing.setLandmark(resultSet.getString("landmark"));
                crossing.setAddress(resultSet.getString("address"));
                crossings.add(crossing);
            }
        }
        return crossings;
    }

    private boolean checkIfFavoriteCrossing(int crossingId) throws SQLException {
        String sql = "SELECT * FROM favorite_crossings WHERE crossing_id = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
             PreparedStatement statement = conn.prepareStatement(sql)) {
            statement.setInt(1, crossingId);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next();
            }
        }
    }
}