package com.simpli;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/delete_crossing")
public class DeleteCrossingServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve the crossing ID from the request
        int crossingId = Integer.parseInt(request.getParameter("id"));

        // Display the confirmation page
        request.setAttribute("crossingId", crossingId);
        request.getRequestDispatcher("delete_crossing_confirm.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve the confirmation parameter from the request
        String confirmation = request.getParameter("confirmation");
        int crossingId = Integer.parseInt(request.getParameter("crossingId"));

        if (confirmation != null && confirmation.equals("yes")) {
            // User confirmed the deletion, proceed with deleting the crossing

            // Database credentials and connection
            String jdbcURL = "jdbc:mysql://localhost:3306/railwaycrossing";
            String dbUser = "root";
            String dbPassword = "tiger";

            Connection connection = null;
            PreparedStatement statement = null;

            try {
                // Load the MySQL JDBC driver
                Class.forName("com.mysql.jdbc.Driver");

                // Establish a connection to the database
                connection = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);

                // Prepare the SQL statement to delete the crossing
                String sql = "DELETE FROM crossing WHERE id = ?";
                statement = connection.prepareStatement(sql);
                statement.setInt(1, crossingId);

                // Execute the SQL statement to delete the crossing
                int rowsDeleted = statement.executeUpdate();

                if (rowsDeleted > 0) {
                    // The crossing was deleted successfully
                    response.sendRedirect("AdminHomeServlet");
                } else {
                    // Failed to delete the crossing
                    response.getWriter().println("Failed to delete the crossing.");
                }
            } catch (ClassNotFoundException | SQLException e) {
                e.printStackTrace();
            } finally {
                // Close the database resources
                if (statement != null) {
                    try {
                        statement.close();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
                if (connection != null) {
                    try {
                        connection.close();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        } else {
            // User canceled the deletion, redirect back to the crossing list
            response.sendRedirect("AdminHomeServlet");
        }
    }
}