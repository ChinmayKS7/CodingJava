package JavaCodes;

//extends Thread
//implements Runnable

class Task1 extends Thread{
	public void run() {
		
		System.out.print("\nTask1 started");
		for(int i=101;i<=199;i++) {
			System.out.print(i + " ");
		}
		
		System.out.print("\nTask1 done");
	}
}

class Task2 implements Runnable{
	public void run() {
		System.out.print("\nTask2 started");
		for(int i=201;i<=299;i++) {
			System.out.print(i + " ");
			}
			
			System.out.print("\nTask2 done");
	}
}

public class ThreadRunnable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
          
		//Task1
		System.out.print("\nTask1 kickedoff");
		  Task1 task1 = new Task1();
		  task1.start();
		
		//Task2
		System.out.print("\nTask2 Kickedoff ");
		Task2 task2 = new Task2();
		Thread taskThread =  new Thread(task2);
		taskThread.start();
		
		//Task3
		System.out.print("\nTask3 Kickedoff ");
		for(int i=301;i<=399;i++) {
		System.out.print(i + " ");
		}
		
		System.out.print("\nTask3 done");
		
		System.out.print("\nMain done");
		
	}

}
