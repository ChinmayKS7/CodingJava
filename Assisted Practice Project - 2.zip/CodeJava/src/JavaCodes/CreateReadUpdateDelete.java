package JavaCodes;

import java.io.File;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;

public class CreateReadUpdateDelete {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String fileName = "files.txt";

        // Create a file
        createFile(fileName);

     // Write data to the file
        String data = "Work from Home";
        writeFile(fileName, data);
        
        // Read data from the file
        String readData = readFile(fileName);
        System.out.println("Data read from file: " + readData);

        // Update data in the file
        String updatedData = "Work in Office";
        updateFile(fileName, updatedData);

        // Read the updated data from the file
        String updatedReadData = readFile(fileName);
        System.out.println("Updated data read from file: " + updatedReadData);

        // Delete the file
        deleteFile(fileName);
	}
	
	public static void createFile(String fileName) {
        try {
            File file = new File(fileName);
            if (file.createNewFile()) {
                System.out.println("File created: " + file.getName());
            } else {
                System.out.println("File already exists.");
            }
        } catch (IOException e) {
            System.out.println("An error occurred while creating the file.");
            e.printStackTrace();
        }
    }
	
	public static void writeFile(String fileName, String data) {
        try {
            FileWriter writer = new FileWriter(fileName);
            writer.write(data);
            writer.close();
            System.out.println("Successfully wrote to the file.");
        } catch (IOException e) {
            System.out.println("An error occurred while writing to the file.");
            e.printStackTrace();
        }
    }

    

    public static String readFile(String fileName) {
        try {
            FileReader reader = new FileReader(fileName);
            StringBuilder data = new StringBuilder();
            int character;
            while ((character = reader.read()) != -1) {
                data.append((char) character);
            }
            reader.close();
            return data.toString();
        } catch (IOException e) {
            System.out.println("An error occurred while reading the file.");
            e.printStackTrace();
        }
        return null;
    }

    public static void updateFile(String fileName, String updatedData) {
        try {
            FileWriter writer = new FileWriter(fileName);
            writer.write(updatedData);
            writer.close();
            System.out.println("Successfully updated the file.");
        } catch (IOException e) {
            System.out.println("An error occurred while updating the file.");
            e.printStackTrace();
        }
    }

    public static void deleteFile(String fileName) {
        File file = new File(fileName);
        if (file.delete()) {
            System.out.println("File deleted: " + file.getName());
        } else {
            System.out.println("Failed to delete the file.");
        }
    }

}
