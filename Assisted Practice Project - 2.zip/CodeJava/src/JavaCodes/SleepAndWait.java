package JavaCodes;

public class SleepAndWait {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		final Object lock = new Object();

        Thread sleepThread = new Thread(() -> {
            synchronized (lock) {
                System.out.println("Sleeping thread is starting.");
                try {
                    // Sleep for 2 seconds
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println("Sleeping thread is awake.");
            }
        });

        Thread waitThread = new Thread(() -> {
            synchronized (lock) {
                System.out.println("Waiting thread is starting.");
                try {
                    // Wait indefinitely until notified
                    lock.wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println("Waiting thread is notified and continues execution.");
            }
        });

        sleepThread.start();
        waitThread.start();
	}

}
