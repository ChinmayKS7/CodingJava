package JavaCodes;

class CustomException extends Exception {
    public CustomException(String message) {
        super(message);
    }
}

public class ThrowCustFinal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         
		 try {
	            // Code that may throw an exception
	            throwCustomException();
	        
	        } catch (CustomException e) {
	            System.out.println("CustomException caught: " + e.getMessage());
	        } finally {
	            System.out.println("Finally block executed.");
	        }
	    }

	    
	    public static void throwCustomException() throws CustomException {
	        throw new CustomException("Custom Exception occurred.");
	}

}
