package com.ecommerce.exceptions;

public class ProductNotFoundException extends RuntimeException{

}
