package JavaPractice;

public class ClassA {
    private int outerVar = 10;

    public void outerMethod() {
        ClassB innerObj = new ClassB();
        innerObj.innerMethod();
    }

    public class ClassB {
        private int innerVar = 5;

        public void innerMethod() {
            System.out.println("Inner method called");
            System.out.println("Outer variable: " + outerVar);
            System.out.println("Inner variable: " + innerVar);
        }
    }

    public static void main(String[] args) {
        ClassA outerObj = new ClassA();
        outerObj.outerMethod();
    }
}