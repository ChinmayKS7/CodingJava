package JavaPractice;

public class AccessModifiers {
      
	    // Public method accessible from anywhere
	    public void publicMethod() {
	        System.out.println("This is a public method.");
	    }

	    // Protected method accessible within the same package and subclasses
	    protected void protectedMethod() {
	        System.out.println("This is a protected method.");
	    }

	    // Default method accessible within the same package
	    void defaultMethod() {
	        System.out.println("This is a default method.");
	    }

	    // Private method accessible only within the same class
	    private void privateMethod() {
	        System.out.println("This is a private method.");
	    }

	    public static void main(String[] args) {
	        AccessModifiers type = new AccessModifiers();

	        type.publicMethod();
	        type.protectedMethod();
	        type.defaultMethod();
	        type.privateMethod(); // Error: Cannot access private method from outside the class
	    }
	}

