package JavaPractice;

import java.util.HashMap;
import java.util.Map; 

public class Maps {

		public static void main(String[] args) {
	        // Create a map to store student details
	        Map<String, Integer> employeeMap = new HashMap<>();

	        // Add student details to the map
	        employeeMap.put("Rocky", 30000);
	        employeeMap.put("Ravi", 32000);
	        employeeMap.put("Avinash", 34000);

	        // Print the map of student details
	        System.out.println("Map of Employee Details:");
	        for (Map.Entry<String, Integer> entry : employeeMap.entrySet()) {
	            String name = entry.getKey();
	            int salary = entry.getValue();
	            System.out.println("Name: " + name + ", Salary : " + salary);
	        }

	        // Update student details
	        employeeMap.put("Rocky", 36000);

	        // Print the updated map
	        System.out.println("\nUpdated Map of Employee Details:");
	        for (Map.Entry<String, Integer> entry : employeeMap.entrySet()) {
	            String name = entry.getKey();
	            int salary = entry.getValue();
	            System.out.println("Name: " + name + ", Salary : " + salary);
	        }

	        // Check if a student exists in the map
	        String searchName = "Ravi";
	        if (employeeMap.containsKey(searchName)) {
	            int salary = employeeMap.get(searchName);
	            System.out.println("\n'" + searchName + "' is in the map with Salary : " + salary);
	        } else {
	            System.out.println("\n'" + searchName + "' is not in the map.");
	        }
	    }
	}
	


