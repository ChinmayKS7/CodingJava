package JavaPractice;

public class RegularExpression {
   
	public static void main(String[] args) {
        // Define a regular expression pattern for splitting text into words
        String text = "These are the words of the text";

        // Split the text into words using the pattern
        String[] words = text.split("\\W+");

        // Display the words
        for (String word : words) {
            System.out.println(word);
        }
    }
}
