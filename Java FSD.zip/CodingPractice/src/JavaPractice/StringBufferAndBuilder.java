package JavaPractice;

public class StringBufferAndBuilder {
      
	public static void main(String[] args) {
        // Create a string
        String str = "Bermuda , Triangle";

        // Convert the string to StringBuffer
        StringBuffer stringBuffer = new StringBuffer(str);

        // Convert the StringBuffer to StringBuilder
        StringBuilder stringBuilder = new StringBuilder(stringBuffer);

        // Display the converted strings
        System.out.println("Original String: " + str);
        System.out.println("Converted StringBuffer: " + stringBuffer.toString());
        System.out.println("Converted StringBuilder: " + stringBuilder.toString());
    }

}
