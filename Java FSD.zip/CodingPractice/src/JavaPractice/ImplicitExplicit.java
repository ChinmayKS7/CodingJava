package JavaPractice;

import java.util.Scanner;

public class ImplicitExplicit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		   Scanner s = new Scanner(System.in);
		   System.out.println("Enter num1 :");
		   int num1 = s.nextInt();
		   
		   double num2 = num1;
		   System.out.println("Implicit type casting :");
           System.out.println("num1(int) - " + num1);
           System.out.println("num2(double) - "+ num2);
           
           System.out.println("\nEnter num3 :");
           double num3 = s.nextDouble();
           int num4 = (int)num3;
           
           System.out.println("Explicit type casting :");
           System.out.println("num3(double) - "+ num3);
           System.out.println("num4(int) - " + num4);
                  
	}

}
