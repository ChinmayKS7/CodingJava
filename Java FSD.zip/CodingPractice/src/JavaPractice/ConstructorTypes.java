package JavaPractice;

public class ConstructorTypes {

	private String name;
    private int age;

    // Default constructor
    public ConstructorTypes() {
        System.out.println("Default constructor called.");
        name = "Rahul Sharma";
        age = 34;
}
    // Parameterized constructor
    public ConstructorTypes(String name, int age) {
        System.out.println("Parameterized constructor called.");
        this.name = name;
        this.age = age;
    }

    // Copy constructor
    public ConstructorTypes(ConstructorTypes other) {
        System.out.println("Copy constructor called.");
        this.name = other.name;
        this.age = other.age;
    }

    public void displayInfo() {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
    }

    public static void main(String[] args) {
        ConstructorTypes type1 = new ConstructorTypes(); // Default constructor
        ConstructorTypes type2 = new ConstructorTypes("Sachin", 23); // Parameterized constructor
        ConstructorTypes type3 = new ConstructorTypes(type2); // Copy constructor

        System.out.println("Type 1:");
        type1.displayInfo();
        System.out.println("Type 2:");
        type2.displayInfo();
        System.out.println("Type 3:");
        type3.displayInfo();
    }
}