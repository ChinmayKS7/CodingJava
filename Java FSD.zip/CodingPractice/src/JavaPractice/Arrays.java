package JavaPractice;

public class Arrays {
	
	public static void main(String[] args) {
        // Declare and initialize an integer array
        int[] numbers = { 10, 30, 50, 70, 90 };

        // Access and print elements of the array
        System.out.println("Elements of the array:");
        for (int i = 0; i < numbers.length; i++) {
            System.out.println(numbers[i]);
        }

        // Update an element of the array
        numbers[4] = 110;

        // Access and print updated elements of the array
        System.out.println("\nUpdated elements of the array:");
        for (int number : numbers) {
            System.out.println(number);
        }

        // Declare and initialize a string array
        String[] names = { "Charan", "Vinod", "Bhargav" };

        // Access and print elements of the string array
        System.out.println("\nElements of the string array:");
        for (String name : names) {
            System.out.println(name);
        }
    }

}
