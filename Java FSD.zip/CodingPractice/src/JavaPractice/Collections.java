package JavaPractice;

import java.util.*;

public class Collections {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer> al = new ArrayList<Integer>();
       
        al.add(3);
        al.add(17);
        al.add(6);
        al.add(9);
        al.add(7);
        System.out.println("The numbers are");   
         
        for (Integer num : al) {         
            System.out.println(num);   
        }
    }

	}


