package JavaPractice;

public class WaysOfMethod {
	
	public static void printMessage(String message) {
        System.out.println(message);
    }
	
	public static int add(int a, int b) {
        return a + b;
    }
	
    public static int factorial(int n) {
        if (n == 0 || n == 1) {
            return 1;
        } else {
            return n * factorial(n - 1);
        }
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		printMessage("I have a message");
		
		
		int sum = add(7, 3);
        System.out.println("Sum: " + sum);

      
        int fact = factorial(7);
        System.out.println("Factorial: " + fact);

	}

}
