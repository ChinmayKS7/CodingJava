package Phase1Project;

public class Camera {

	private int camera_id;
    private String brand;
    private String model;
    private double rentalAmount;
    private boolean status;

    public Camera(int camera_id,String brand, String model, double rentalAmount,boolean Available) {
    	this.camera_id = camera_id;
        this.brand = brand;
        this.model = model;
        this.rentalAmount = rentalAmount;
        this.status = Available;
    }
    
    public int getId() {
		return camera_id;
	}

    public String getBrand() {
        return brand;
    }

    public String getModel() {
        return model;
    }

    public double getRentalAmount() {
        return rentalAmount;
    }
    
    public boolean isAvailable() {
		return status;
	}
    
    public void setAvailable(boolean Available) {
		this.status = Available;
	}
}
