package Phase1Project;

import java.util.ArrayList;
import java.util.Scanner;


public class CameraRentalApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 System.out.println("\n**************************************\n");
	     System.out.println("\tWelcome to Camera Rental Application \n");
	     System.out.println("**************************************");
	     
	     double INR = 2000;
			String username, password;

			Scanner s = new Scanner(System.in);
			System.out.print("Enter username:");// username:sai
			username = s.nextLine();
			System.out.print("Enter password:");// password:Sai@123
			password = s.nextLine();
			if (username.equals("bmw") && password.equals("Bmw@123")) {
				System.out.println("Logged in Successfuly");
				ArrayList<Camera> list = new ArrayList<>();
				list.add(new Camera(1, "Samsung", "DS123", 100, true));
				list.add(new Camera(2, "Sony", "HD214", 300, true));
				list.add(new Camera(3, "Pansonic", "XC", 550, true));
				list.add(new Camera(4, "Canon", "XLR", 200, true));
				list.add(new Camera(5, "LG", "L123", 1500, true));
				list.add(new Camera(6, "Chroma", "CT", 2650, true));
				list.add(new Camera(7, "Nikon", "DSLR-D7500", 850, true));
				list.add(new Camera(8, "Fujitsu", "J5", 320, true));
				// int l=list.size();
				int x = 0;
				do {
					int option;
					Scanner sc = new Scanner(System.in);
					// public void main_option()
					System.out.println("1.MY CAMERA");
					System.out.println("2.RENT A CAMERA");
					System.out.println("3.VIEW ALL CAMERA");
					System.out.println("4.MY WALLET");
					System.out.println("Exit");
					System.out.println("Select your option : ");
					option = sc.nextInt();

					switch (option) {
					case 1:
						int k = 0;
						do {
							int choose;
							System.out.println("1.ADD");
							System.out.println("2.REMOVE");
							System.out.println("3.VIEW MY CAMERA");
							System.out.println("4.GO TO PREVIOUS MENU");
							System.out.println("Enter your choise : ");
							choose = sc.nextInt();

							switch (choose) {

							case 1:
								System.out.println("Enter Camera ID: ");
								int camera_id = sc.nextInt();
								System.out.println("Enter Camera Brand: ");
								String brand = sc.next();
								System.out.println("Enter Camera Model: ");
								String model = sc.next();
								System.out.println("Enter Camera rentalAmount : ");
								double rentalAmount = sc.nextFloat();
								boolean Available = true;
								list.add(new Camera(camera_id, brand, model, rentalAmount, Available));
								System.out.println("Added Successfully");
								System.out.println("IF u want to view the list please enter '1' else enter '0': ");
								int m = sc.nextInt();
								if (m == 1) {
									System.out.println("cameraID\t Brand\t Model\t rentalAmount\t Status");
									for (int i = 0; i < list.size(); i++) {
										Camera camera = list.get(i);
										String status = camera.isAvailable() ? "Available" : "Rended";
										System.out.println(camera.getId() + "\t\t" + camera.getBrand() + "\t" + camera.getModel()
												+ "\t" + camera.getRentalAmount() + "\t" + status);
									}

								}
								break;
							case 2:
								System.out.println("Enter the cameraId you want to remove from the list: ");
								int cameraId = sc.nextInt();
								for (int i = 0; i < list.size(); i++) {
									Camera camera = list.get(i);
									if (camera.getId() == cameraId) {
										list.remove(i);
										break;
									}
								}
								break;
							case 3:
								System.out.println("cameraId\t brand\t model\t rentalAmount\t status");
								for (int i = 0; i < list.size(); i++) {
									Camera camera = list.get(i);
									String status = camera.isAvailable() ? "Available" : "Rended";
									System.out.println(camera.getId() + "\t\t" + camera.getBrand() + "\t" + camera.getModel()
											+ "\t" + camera.getRentalAmount() + "\t" + status);
								}
							case 4:
								x = 1;
								break;
							}
							System.out.println("If u want to add or remove camera please enter '1' else '0':");
							k = sc.nextInt();
						} while (k == 1);
						break;

					case 2:

						System.out.println("cameraId\t brand\t model\t rentalAmount\t status");
						for (Camera camera : list) {
							if (camera.isAvailable()) {
								String status = camera.isAvailable() ? "Available" : "Rended";

								System.out.println(camera.getId() + "\t\t" + camera.getBrand() + "\t" + camera.getModel() + "\t"
										+ camera.getRentalAmount() + "\t" + status);
							}
						}
						int index = -1;
						System.out.println(" Enter the cameraId you want to rent : ");
						int cameraId = sc.nextInt();
						for (int i = 0; i < list.size(); i++) {
							Camera camera = list.get(i);
							if (camera.getId() == cameraId) {
								index = i;
								break; // Found the camera, exit the loop
							}
						}
						if (index != -1) {
							Camera a = list.get(index);
							if (a.getRentalAmount() <= INR) {
								System.out.println("Rented Successfully");
								a.setAvailable(false);
								INR = INR - a.getRentalAmount();
								System.out.println("Current balance of the wallet - " + INR);
							} else {
								System.out.println("You don't have Sufficient Balance in the wallet");
							}
						} else {
							System.out.println("Camera with ID " + cameraId + " is not found in the list.");
						}

						break;

					case 3:
						System.out.println("cameraId\t brand\t model\t rentalAmount\t status");
						for (int i = 0; i < list.size(); i++) {
							Camera camera = list.get(i);
							String status = camera.isAvailable() ? "Available" : "Rented";
							System.out.println(camera.getId() + "\t\t" + camera.getBrand() + "\t" + camera.getModel() + "\t"
									+ camera.getRentalAmount() + "\t" + status);
						}
						break;
					case 4:
						System.out.println("Your current wallet balance is :" + INR);
						System.out.println("Do you want to deposit amount to your wallet?(1.Yes 2.No)- ");
						int m = sc.nextInt();
						if (m == 1) {
							System.out.println("Enter deposit amount: ");
							double addAmount = sc.nextDouble();
							INR = INR + addAmount;
							System.out.print("Your Wallet balance got updated successfully...");
						}
						System.out.println("Current wallet balance - " + INR);
						break;
					}
					System.out.println("Do u want to continue (1.Yes 2.No)- ");
					x = sc.nextInt();
				} while (x == 1);
			} else {
				System.out.println("Authentication Failed");
			}
			System.out.println("Thank you for visiting the Camera rental Application");
	} 
	
	   
		
	}
	
