package DataStructure;

public class Stack {
	
     final int MAX_SIZE = 5;
    int[] stackArray = new int[MAX_SIZE];
    int top = -1;

    

    public void push(int value) {
        if (top == MAX_SIZE -1 ) {
            System.out.println("Stack overflow. Cannot push element: " + value);
            return;
        }
        stackArray[++top] = value;
        System.out.println("Pushed element: " + value);
    }

    public int pop() {
        if (top == -1) {
            System.out.println("Stack underflow. Cannot pop element.");
            return -1; // Return a default value indicating stack underflow
        }
        int poppedElement = stackArray[top--];
        System.out.println("Popped element: " + poppedElement);
            return poppedElement;
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stack num = new Stack();

        num.push(10);
        num.push(20);
        num.push(30);
        num.push(40);
        num.push(50);
        num.push(60);

        num.pop();
       num.pop();
        num.pop();
        num.pop();
        num.pop();
        num.pop();
        
        

	}

}
