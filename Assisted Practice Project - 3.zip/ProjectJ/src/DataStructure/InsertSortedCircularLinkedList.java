package DataStructure;

class Nodes {
    int data;
    Nodes next; 

    public Nodes(int data) {
        this.data = data;
        this.next = null;
    }
}

class CircularLinkedList {
    private Nodes head;

    public CircularLinkedList() {
        head = null;
    }

    public void insert(int data) {
        Nodes newNode = new Nodes(data);

        if (head == null) {
            newNode.next = newNode; // Make the new node point to itself
            head = newNode;
        } else if (data <= head.data) {
            Nodes current = head;
            while (current.next != head) {
                current = current.next;
            }
            current.next = newNode;
            newNode.next = head;
            head = newNode;
        } else {
            Nodes current = head;
            while (current.next != head && current.next.data < data) {
                current = current.next;
            }
            newNode.next = current.next;
            current.next = newNode;
        }
    }

    public void display() {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }

        Nodes current = head;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);
        System.out.println();
    }
}

public class InsertSortedCircularLinkedList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CircularLinkedList list = new CircularLinkedList();

        // Insert elements into the list
        list.insert(10);
        list.insert(20);
        list.insert(30);
        list.insert(40);
        list.insert(50);

        System.out.println("Original List:");
        list.display();

        // Insert new element
        int newElement = 35;
        list.insert(newElement);

        System.out.println("List after inserting " + newElement + ":");
        list.display();
	}

}
