package DataStructure;

class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class LinkedList {
    private Node head;

    public LinkedList() {
        head = null;
    }

    public void insert(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    public void delete(int key) {
        if (head == null) {
            System.out.println("List is empty. Cannot delete.");
            return;
        }

        if (head.data == key) {
            head = head.next;
            System.out.println("Deleted first occurrence of " + key);
            return;
        }

        Node current = head;
        Node previous = null;

        while (current != null && current.data != key) {
            previous = current;
            current = current.next;
        }

        if (current == null) {
            System.out.println("Key not found in the list.");
        } else {
            previous.next = current.next;
            System.out.println("Deleted first occurrence of " + key);
        }
    }

    public void display() {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }

        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
}

public class DeleteFirstOccurenceLinkedList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 LinkedList list = new LinkedList();

	        // Insert elements into the list
	        list.insert(10);
	        list.insert(20);
	        list.insert(30);
	        list.insert(40);
	        list.insert(50);

	        System.out.println("Original List:");
	        list.display();

	        // Delete first occurrence of key
	        int key = 30;
	        list.delete(key);

	        System.out.println("List after deleting " + key + ":");
	        list.display();
	}

}
