package DataStructure;

class Node1 {
    int data;
    Node1 previous;
    Node1 next;

    public Node1(int data) {
        this.data = data;
        this.previous = null;
        this.next = null;
    }
}

class DoublyLinkedList {
    private Node1 head;
    private Node1 tail;

    public DoublyLinkedList() {
        head = null;
        tail = null;
    }

    public void insert(int data) {
        Node1 newNode = new Node1(data);

        if (head == null) {
            head = newNode;
            tail = newNode;
        } else {
            tail.next = newNode;
            newNode.previous = tail;
            tail = newNode;
        }
    }

    public void displayForward() {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }

        Node1 current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    public void displayBackward() {
        if (tail == null) {
            System.out.println("List is empty.");
            return;
        }

        Node1 current = tail;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.previous;
        }
        System.out.println();
    }
}

public class DoublyLinkedListTraverse {
	public static void main(String[] args) {
	DoublyLinkedList list = new DoublyLinkedList();

    // Insert elements into the list
    list.insert(10);
    list.insert(20);
    list.insert(30);
    list.insert(40);
    list.insert(50);

    System.out.println("Forward traversal:");
    list.displayForward();

    System.out.println("Backward traversal:");
    list.displayBackward();
}
}