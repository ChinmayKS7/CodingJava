package DataStructure;

import java.util.Arrays;

public class FourthSmallestElement {
	
	public static int findFourthSmallest(int[] arr) {
        if (arr.length < 4) {
            System.out.println("Array should have at least 4 elements.");
            return -1;
        }

        Arrays.sort(arr); // Sort the array in ascending order

        return arr[3]; // Return the fourth element (index 3)
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = {9, 4, 7, 2, 1, 5, 8, 3, 6};

        System.out.println("Array: " + Arrays.toString(arr));

        int fourthSmallest = findFourthSmallest(arr);
        System.out.println("Fourth smallest element: " + fourthSmallest);

	}

}
